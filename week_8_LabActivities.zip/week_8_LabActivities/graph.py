# ===graph.py===
class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            self.graph.pop(vertex)

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:  # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:  # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
            if self.weighted:
                self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:  # Check that vertices are present
            self.graph[vertex1] = []
            self.graph[vertex2] = []
        else:
            print("One or both vertices not found in graph.")

    def print_graph(self):
        print(f'{self.graph} \n')

    def has_undirected_cycle(self):
        key_list = []
        for i in self.graph:
            key_list.append(i)

        key_first = key_list[0]
        key_last = key_list[-1]
        value_last = self.graph[key_last]

        if key_first in value_last:
            return 'Yes'
        else:
            return 'No'


    def bfs(self, vertex):
        visited = set()

        if vertex in self.graph:
            queue = [vertex]
            while queue:
                node = queue.pop(0)
                if node not in visited:
                    visited.add(node)
                    queue += self.graph[node]

            return visited

        else:
            print('Vertex not found in graph.')

    def dfs(self, vertex):
        visited = set()

        if vertex in self.graph:
            stack = [vertex]
            while stack:
                node = stack.pop()
                if node not in visited:
                    visited.add(node)
                    stack += self.graph[node]
            return visited

        else:
            print('Vertex not found in graph.')


test = Graph()
test.add_vertex('A')
test.add_vertex('B')
test.add_vertex('C')
test.add_edge('A', 'B')
test.add_edge('A', 'C')
test.print_graph()


