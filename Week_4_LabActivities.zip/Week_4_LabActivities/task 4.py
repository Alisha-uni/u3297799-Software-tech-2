import timeit
import random

def linear_search(array, target):
    for i in range(len(array)):
        if array[i] == target:
            return i

    return -1

def binary_search(array, target):
    # Initialize 'pointers'
    left = 0
    right = len(array) - 1  # Account for indexing to get the right most element index
    mid = int((left + right) / 2)

    while left <= right:
        if array[mid] == target:  # If target is found
            return mid
        elif target > array[mid]:
            left = mid + 1  # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right) / 2)  # Recalculate mid

    return -1

def bubble_sort(arr):

    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):

        # Flag to optimize the algorithm
        # If no swaps are performed in an iteration, the list is already sorted, and we can stop early
        swapped = False

        # Last i elements are already in place, so we don't need to compare them again
        for j in range(0, n - i - 1):

            # Compare adjacent elements
            if arr[j] > arr[j + 1]:
                # Swap if the element found is greater than the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, the list is sorted, and we can exit early
        if not swapped:
            break

    return arr

def insertion_sort(arr):

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr

#insertion sort + linear search
def IsortLsearch(target, unsorted_list):
    insertionSorted = insertion_sort(unsorted_list)
    linear_search(insertionSorted, target)

#bubble sort + linear search
def BsortLsearch(target, unsorted_list):
    bubbleSorted = bubble_sort(unsorted_list)
    linear_search(bubbleSorted, target)

#insertion sort + binary search
def IsortBsearch(target, unsorted_list):
    insertionSorted = insertion_sort(unsorted_list)
    binary_search(insertionSorted, target)

#bubble sort + binary search
def BsortBsearch(target, unsorted_list):
    bubbleSorted = bubble_sort(unsorted_list)
    binary_search(bubbleSorted, target)


sortRange = 1000
testList = [random.randint(1, sortRange) for _ in range(sortRange)]
number = random.randint(1, sortRange)
#this while loop has been added incase the target number initially chosen was not in the list
while number not in testList:
    number = random.randint(1, sortRange)

print(f"Sorting a list size of {sortRange}")
print(f"Looking for {number}")
print("\n")


IsortLsearch_time = timeit.timeit(lambda: IsortLsearch(number, testList), number=100)
BsortLsearch_time = timeit.timeit(lambda: BsortLsearch(number, testList), number=100)
IsortBsearch_time = timeit.timeit(lambda: IsortBsearch(number, testList), number=100)
BsortBsearch_time = timeit.timeit(lambda: BsortBsearch(number, testList), number=100)

print(f"Insertion sort + linear search execution time: {IsortLsearch_time:.6f} seconds")
print(f"Bubble sort + linear search execution time: {BsortLsearch_time:.6f} seconds")
print("\n")
print(f"Insertion sort + binary search execution time: {IsortBsearch_time:.6f} seconds")
print(f"Bubble sort + binary search execution time: {BsortBsearch_time:.6f} seconds")