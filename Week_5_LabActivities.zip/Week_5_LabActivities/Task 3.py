# TowerOfHanoi.py
global moveNum
moveNum = 1

def main():
    n = eval(input("Enter number of disks: "))
    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print(f"Number of moves is: {moveNum}")

# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global moveNum

    if n == 1: # Stopping condition
        pass
        #print("Move disk", n, "from", fromTower, "to", toTower)
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        moveNum += 1
        #print("Move disk", n, "from", fromTower, "to", toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)
        moveNum += 1

main() # Call the main function