num = 10

print(f"Data size {num} \n")

# RECURSION
# At its core, recursion involves solving a problem
# by breaking it down into smaller, more manageable instances of the same problem.


# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

# Example usage:
result = sum_of_natural_numbers(num)
print(f"The sum of the first {num} natural numbers is {result}")


# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

# Example usage:
result = fibonacci(num)
print(f"The {num}th Fibonacci number is {result}")



# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

# Example usage:
result = factorial(num)
print(f"The factorial of {num} is {result}")

print("\nWith functions converted to iteration:")
print(f"Data size {num} \n")

def sum_of_natural_numbers_iterative(n):
    total = 0

    for i in range(1, n+1):
        total += i

    return total

result = sum_of_natural_numbers_iterative(num)
print(f"The sum of the first {num} natural numbers is {result}")

# f(n) = f(n - 1) + f(n - 2)
def fibonacci_iterative(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case

    a = 0
    b = 1

    for i in range(2, n+1):
        c = a + b
        a = b
        b = c

    return b

result = fibonacci_iterative(num)
print(f"The {num}th Fibonacci number is {result}")

def factorial_iterative(n):
    #n! = n * (n-1)
    total = n

    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    elif n == 1:
        return 1

    for i in range(2, n+1):
        total = total * (i - 1)
        #print(total)

    return total

result = factorial_iterative(num)
print(f"The factorial of {num} is {result}")